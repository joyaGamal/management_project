
// play skitter slider 
$(document).ready(function() {
    $(".skitter-large").skitter({
      dots:false,
      responsive:
      { responsive: { small: { animation: 'fade', max_width: 768, max_height: 700 , suffix: '-small' },
       medium: { animation: 'directionRight', max_width: 1024, max_height: 700 , suffix: '-medium' } } }
      
    });
  });

// play wow
  new WOW().init();

// dropdwon services
  $(".dropdown-links").click(function() {
    $(".category").toggle(.5000);
    })

    // play function owl carousel
    $(document).ready(function(){
      $('.owl-carousel').owlCarousel({
        margin:20,
        loop:true,
          
        });
    });

// Effect On Section Courses 
let btnBox = document.querySelectorAll(".btn-box");
btnBox.forEach(li => {
  //Clicl On Every list Items
  li.addEventListener("click", (e)=> {
    let boxContainer =document.querySelectorAll(".box-container");
      boxContainer.forEach(a =>{
        a.classList.toggle("sohw-box");
    })
  });
});

// Play Active In Navbare
$(document).ready(function(){
  $('.navbar ul li a').click(function(){
    $('li a').removeClass("active");
    $(this).addClass("active")
  })
})